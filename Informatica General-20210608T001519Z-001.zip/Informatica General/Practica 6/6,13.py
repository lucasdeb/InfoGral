def main():
    d = agregarDicEle()
    print("El diccionario retornado: ")
    print(d)
    n = int(input("Ingresa un numero a traducir o 0 para salir: "))
    while n != 0:
        if n in d:
            print(n,"->",d[n])
            n = int(input("Ingresa un numero a traducir o 0 para salir: "))
        else:
            n = int(input("Error, ingresa un numero a traducir o 0 para salir: "))





def agregarDicEle():
    d = {}
    salir = "n"
    while salir != "s":
        clave = int(input("Ingresar numero entero: ")) # numeros enteros
        valor = str(input("Ingresar nombre de numero: ")) # nombre de numero
        d[clave] = valor
        salir = str(input("Desea salir? (s/n): "))
    return d
main()