def main():
    print("1. Cargar Conjuntos")
    print("2. Union")
    print("3. Interseccion")
    print("4. Diferencia")
    print("5. Diferencia Simetrica")
    print("6. Salir")
    valor = int(input("Ingrese valor de la opcion: "))
    #cargarlista()
    print(v)
"""
def cargarlista():
    lst = []
    lst1 = []
    n = int(input("Ingrese un numero entero positivo, y 0 para terminar: "))
    while n != 0:
        if ((validar(n)) == True):
            if ((estaEnLista(n,lst)) == False):
                lst.append(n)
                n = int(input())
            else:
                print("Error, numero repetido")
                n = int(input())
        else:
            print("Error, numero NO positivo")
            n = int(input())
    return lst
"""  
def cargarconjuntos():
    v = "hello"
    
main()