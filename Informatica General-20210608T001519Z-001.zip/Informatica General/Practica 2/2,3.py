def main():
    n = int(input("Ingrese un numero binario de hasta 8 bits: "))
    
    paridad(n)
    
    if paridad(n) == True:
        print("Bit de paridad generado: 0")
    if paridad(n) == False:
        print("Bit de paridad generado: 1")

def paridad(n):
    
    n1 = n%10
    n2 = n//10%10
    n3 = n//100%10
    n4 = n//1000%10
    n5 = n//10000%10
    n6 = n//100000%10
    n7 = n//1000000%10
    n8 = n//10000000%10
    
    p = n1+n2+n3+n4+n5+n6+n7+n8
    
    if p%2 == 0:
        return True
    else:
        return False
main()