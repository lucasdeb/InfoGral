def main():
    r = int(input("ingrese el radicando (numero real):"))
    i = int(input("ingrese el indice (numero natural):"))
    raiz = sol(r,i)
    print("la raiz", i, "de", r, "es =", raiz)

def sol(r,i):
    
    raiz = r**(1/i)
    
    return raiz

main()
    
    