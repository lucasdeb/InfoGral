import random

def main():
    li = int(input("ingrese el limite inferior:"))
    ls = int(input("ingrese el limite superior:"))
    ng1 = random.randrange(li,ls+1)
    ng2 = random.randrange(ng1,ls+1)
    ng3 = random.randrange(ng1, ng2+1)
    print(li, ng1, ls,"/", ng1, ng2, ls, "/", ng1, ng3, ng2)
main()
    
    