import math

def main():
    l = int(input("ingrese lado de cuadrado:"))
    area = areacirc(l)
    areac = areacuad(l)
    arean = arean(areac, area)
    pork = 100*arean/areac
    print(arean, pork,"%")
def areacirc(l):
    d1 = l*(2/3)
    d2 = l*(1/3)
    area1 = math.pi*(d1/2)**2
    area2 = math.pi*(d2/2)**2
    area = area1+2*(area2)
    
    return area

def areacuad(l):
    areac = l**2
    
    return areac

def arean(areac, area):
    arean = areac-area

    return arean
main()