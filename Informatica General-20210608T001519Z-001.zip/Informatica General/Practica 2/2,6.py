import random

def main():
    v1 = input("ingrese alternativa 1 para vestimenta:")
    v2 = input("ingrese alternativa 2 para vestimenta:")
    
    p1 = input("ingrese alternativa 1 para plato:")
    p2 = input("ingrese alternativa 2 para plato:")
    b1 = input("ingrese alternativa 1 para bebida:")
    b2 = input("ingrese alternativa 2 para bebida:")
    
    bv = random.randint(0,1)
    bp = random.randint(0,1)
    bb = random.randint(0,1)
    
    vc1 = v1*bv
    if bv == 0:
        vc2 = v2*1
    else:
        vc2 = v2*0
    vc = vc1+vc2
    
    pc1 = p1*bp
    if bp ==0:
        pc2 = p2*1
    else:
        pc2 = p2*0
    pc = pc1+pc2
    
    bc1 = b1*bb
    if bb == 0:
        bc2 = b2*1
    else:
        bc2 = b2*0
    bc = bc1+bc2
    
    print("cena al azar:", vc, pc, bc)
    
    

main()

    