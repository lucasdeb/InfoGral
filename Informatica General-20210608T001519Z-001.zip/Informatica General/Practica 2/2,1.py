import math

def main():
    l1 = int(input("ingrese lado 1:"))
    l2 = int(input("ingrese lado 2:"))
    l3 = int(input("ingrese lado 3:"))
    p = (l1+l2+l3)/2
    a = area(l1,l2,l3,p)
    print("el area del triangulo es:",a)
def area(l1,l2,l3,p):
    a = math.sqrt(p*((p-l1)*(p-l2)*(p-l3)))
    
    return a
main()
    