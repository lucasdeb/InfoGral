def main():
    n1 = int(input("Ingrese un numero entero positivo: "))
    if n1%2 == 0:
        if menor(n1) == True:
            print("Correcto!")
        else:
            print("Incorrecto!")
    else:
        if mayor(n1) == True:
            print("Correcto!")
        else:
            print("Incorrecto!")
    
    
def menor(n1):
    n2 = int(input("Ingrese un numero menor que {}: ".format(n1)))
    if n2<n1:
        return True
    else:
        return False
def mayor(n1):
    n2 = int(input("Ingrese un numero mayor que {}: ".format(n1)))
    if n2>n1:
        return True
    else:
        return False
main()