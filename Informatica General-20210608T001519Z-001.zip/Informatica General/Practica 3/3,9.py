def main():
    s = int(input("Ingrese el sueldo base: "))
    h = str(input("Tiene hijos (s/n)?: "))
    c = int(input("Ingrese categoria (1 - 9): "))
    sb = bono(s)
    sh = plush(h,s)
    sc = plusc(c,s)
    plusv = plus(sh,sc)
    st = sb + plusv
    print("El sueldo total sera: ${}".format(st))

def bono(s):
    if s > 2000:
        sb = (s*15)/100 + s
        return sb
    if s < 2000:
        sb = (s*20)/100 + s
        return sb

def plus(sh,sc):
    plusv = sh + sc
    return plusv

def plush(h,s):
    if h == "s":
        sh = (5*s)/100
        return sh
    if h == "n":
        sh == 0
        return sh

def plusc(c,s):
    if c == 1 or c == 2 or c == 3:
        sc = (10*s)/100
    if c == 4 or c == 5 or c == 6:
        sc = (12*s)/100
    if c == 7 or c == 8 or c == 9:
        sc = (20*s)/100
    return sc
main()
        

    