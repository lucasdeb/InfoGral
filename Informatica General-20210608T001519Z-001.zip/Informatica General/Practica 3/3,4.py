def main():
    n1 = int(input("Ingrese numero A: "))
    n2 = int(input("Ingrese numero B: "))
    if validar(n1,n2) == True:
        print("Si cumple con la condicion.")
    else:
        print("No cumple con la condicion.")
def validar(n1,n2):
    if n1 > n2:
        r = n1-n2
        if n1>r>n2:
            return True
        else:
            return False
    if n2 > n1:
        r = n2-n1
        if n2>r>n1:
            return True
        else:
            return False
    if n1-n2 == 0:
        return True
main()