def main():
    n1 = int(input("Ingrese el primer numero: "))
    n2 = int(input("Ingrese el segundo numero: "))
    n3 = int(input("Ingrese el tercer numero: "))
    if validar(n1, n2, n3) == True:
        print("Estan igualmente distanciados")
    else:
        print("No estan igualmente distanciados")

def validar(n1, n2, n3):
    if n1>n2>n3:
        d1 = n1-n2
        d2 = n2-n3
        if d1 == d2:
            return True
        else:
            return False
    if n1>n3>n2:
        d1 = n1-n3
        d2 = n3-n2
        if d1 == d2:
            return True
        else:
            return False
    if n2>n1>n3:
        d1 = n2-n1
        d2 = n1-n3
        if d1 == d2:
            return True
        else:
            return False
    if n2>n3>n1:
        d1 = n2-n3
        d2 = n3-n1
        if d1 == d2:
            return True
        else:
            return False
    if n3>n1>n2:
        d1 = n3-n1
        d2 = n1-n2
        if d1 == d2:
            return True
        else:
            return False
    if n3>n2>n1:
        d1 = n3-n2
        d2 = n2-n1
        if d1 == d2:
            return True
        else:
            return False
main()