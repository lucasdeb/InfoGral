def main():
    n = float(input("Ingrese un numero: "))
    final = "El numero es "
    print(final + pnc(n) + ner(n))
    
def pnc(n):
    f = ""
    if n > 0:
        f += "Positivo"
    if n < 0:
        f += "Negativo"
    if n == 0:
        f += "Cero"
    return f
    
def ner(n):
    fi = ""
    if n%1 != 0:
        fi += " y Real"
    if n%1 == 0 and n > 0:
        fi += " y entero Natural"
    if n%1 == 0 and n <= 0:
        fi += " y Entero"
    return fi 
        
main()
        
        
        
        