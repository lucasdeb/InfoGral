def main():
    n1 = int(input("Ingrese primer numero:"))
    n2 = int(input("Ingrese segundo numero:"))
    o1 = str(input("Ingrese la operacion (+, -, *,/):"))
    if o1 == "+":
        o = n1+n2
    if o1 == "-":
        o = n1-n2
    if o1 == "*":
        o = n1*n2
    if o1 == "/":
        o = n1/n2
    print(n1, o1, n2, "=", o)
    
main()