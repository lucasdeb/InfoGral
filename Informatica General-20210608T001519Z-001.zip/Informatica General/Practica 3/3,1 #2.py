#ej.1
def operacion(n1,n2,op):
    if op == "+":
        opfinal = n1+n2
    elif op == "-":
        opfinal = n1-n2
    elif op == "*":
        opfinal = n1*n2
    elif op == "/":
        opfinal = n1/n2
        
    return opfinal


def main():
    num1 = int(input("Ingrese primer numero: "))
    num2 = int(input("Ingrese segundo numero: "))
    op = input("Ingrese la operacion (+, -, *, /): ")
    print("{} {} {} = {}".format(num1, op, num2,(operacion(num1, num2, op))))
    
main()
                            