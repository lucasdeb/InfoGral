def main():
    a = int(input("Ingrese Cantidad de canos de 1m: "))
    b = int(input("Ingrese cantidad de canos de 5m: "))
    c = int(input("Ingrese metros totales para cubrir "))
    calc(a,b,c)
def calc(a,b,c):
    if c%5 == 0:
        s = c//5
        print("Es posible cubrir el tendido", "/nSugerencia {} de 1m y {} de 5m".format(s))
    if c%5!=0 and c<a:
        s = c//5
        r = c%5
        print("Es posible cubrir el tendido", "/nSugerencia {} de 1m y {} de 5m".format(r,s))
    else:
        print("No es posible cubrir el tendido")
main()