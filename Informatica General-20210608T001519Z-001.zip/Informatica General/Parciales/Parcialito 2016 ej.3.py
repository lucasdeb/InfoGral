def main():
    n = int(input("Ingrese la base: "))
    while validarn(n) == False:
        n = int(input("Ingrese la base: "))
    figura(n)
    

def validarn(n):
    if n >=6 and n%2 == 0:
        return True
    else:
        return False

def figura(n):
    for f in range(0,n+1):
        for c in range(0,n+1):
            if f == n or (f == 0 and c == 0) or f+c == 1 or f+c == n//3 or f == c or f+c == n or c == n or f+c == n//2 or f+c == (n//2)-1 or f+c == ((n//2)-1)//2 or f+c == n//4:
                print(" *", end="")
            else:
                print("  ", end="")
        print()
main()
    