def main():
    validar()
def validar():
    c = 0
    p = 0
    i = 0
    a = 0
    n = int(input("Ingrese un numero positivo: "))
    c += 1
    while n < 0:
        n = int(input("Ingrese un numero positivo: "))
    while n != 0 and n > 0:
        while n != 0:
            if n < 0:
                n = int(input("Ingrese un numero positivo: "))
            if c != 1:
                n = int(input())
            if (n%2 == 0) and (n > 0) == True:
                p += 1
                a += n
                c += 1
            if (n%2 == 0) == False:
                i += 1
                a += n
                c += 1
    av = a/(p+i)
    print("Numeros pares: {}".format(p))
    print("Numeros impares: {}".format(i))
    print("El promedio es: {}".format(av))
                

    
main()
            
            
            
    
    