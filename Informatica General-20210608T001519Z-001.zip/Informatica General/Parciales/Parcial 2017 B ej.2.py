def main():
    num = int(input("Ingrese numero: "))
    val1 = int(input("Ingrese valor 1: "))
    val2 = int(input("Ingrese valor 2: "))
    validarP(num,val1,val2)
def validarP(num,val1,val2):
    if (num%2 == 0 and num != 2) or (num%3 == 0 and num!= 3) or (num%5 == 0 and num!= 5):
        p = False
    else:
        p = True
    if p == True:
        if val1<num<val2:
            v = True
        else:
            v = False
    if p and v == True:
        print("Cumple")
    else:
        print("No Cumple")
main()