def main():
    prom()
def prom():
    p = 0
    f = 0
    pr = 0
    av = 0
    n = int(input("Ingrese nota: "))
    if 1 <= n <4:
        f += 1
        av += n
    if 4 <= n <= 7:
        p += 1
        av += n
    if 7 < n <= 10:
        pr += 1
        av += n
    while n != 0:
        n = int(input("Ingrese nota: "))
        if 1 <= n <4:
            f += 1
            av += n
        if 4 <= n <= 7:
            p += 1
            av += n
        if 7 < n <= 10:
            pr += 1
            av += n
    porcf = 100*f/(p+f+pr)
    porcp = 100*p/(p+f+pr)
    porcpr = 100*pr/(p+f+pr)
    ave = av/(p+f+pr)
    print("Cantidad de aplazados: {} ({:.2f}%)".format(f, porcf))
    print("Cantidad de aprobados: {} ({:.2f}%)".format(p, porcp))
    print("Cantidad de promocionados: {} ({:.2f}%)".format(pr, porcpr))
    print("Promedio General: {:.2f}".format(ave))
main()
    
    