def main():
    n = 0
    cant = int(input("Ingrese cantidad (numero natural): "))
    
    print("Primos entre 1 y {}: ".format(cant))
    for i in range (cant):
        if primos(i) == True:
            if i < 57:
                print(i, end="\t")
            else:
                print(i, end="\t")
    
    print("\nPrimeros {} primos: ".format(cant))
    
    i = 0
    while n < cant:
        if primos(i) == True:
            i += 1
            n += 1
            print(i-1, end="\t")
        else:
            i += 1    
            
def primos(i):
    if ((i % 2 != 0 or i == 2) and (i % 3 != 0 or i == 3) and (i % 5 != 0 or i == 5)) and i != 1:
        return True
    else:
        return False
main()