def main():
    num = int(input("Ingrese un numero de base 10 no mayor a 1000: "))
    print(abinario(num))
    
def abinario(num):
    e = 0
    s = 0
    while num//(2**(e)) != 0:
        s += (num//(2**(e))%2)*(10**(e))
        e += 1
    return s
main()