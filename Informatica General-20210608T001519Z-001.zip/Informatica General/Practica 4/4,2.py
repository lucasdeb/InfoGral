def main():
    max1 = 0
    min1 = 0
    n = int(input("Ingrese numeros enteros positivos: "))
    max1 += n
    min1 += n
    while n != 0:
        n = int(input())
        if n > max1:
            max1 = 0
            max1 += n
        if  n != 0 and n < min1:
            min1 = 0
            min1 += n
        if min1 == 0:
            min1 += n
    print("El mayor es {}, el menor es {}".format(max1,min1))
main()
            