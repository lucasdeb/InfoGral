def main():
    factor()
def factor():
    n1 = 0
    n = int(input("Ingrese un numero entero: "))
    while n < 1:
        print("No se puede calcular factorial de numero negativo")
        n = int(input("Ingrese un numero entero: "))
    if n > 0:
        for i in range(1,n):
            if i == 1:
                n1 = i*n
            else:
                n1 *= i
        print("El factorial de {} es: {}".format(n,n1))
main()