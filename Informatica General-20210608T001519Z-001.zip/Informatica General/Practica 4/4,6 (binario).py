def main():
    n = int(input("Ingrese un numero en base 10: "))
    abinario(n)

def abinario(n):
    binario = 0
    c = 0
    p = 1
    while (n//2**c) != 0:         
        n1 = (n//2**c)%2    
        c += 1
        binario += n1*p
        p = p*10
        
    print("El numero binario es: {}".format(binario))
        
main()