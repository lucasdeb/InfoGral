def main():
    n = int(input("Ingrese un numero: "))
    strn = str(n)
    lenn = len(strn)
    ex = int(lenn)
    if validar(n,ex) == True:
        print("\n{} es capicuo".format(n))
    else:
        print("\n{} no es capicuo".format(n))
def validar(n,ex):
    e = 1
    nuevo_n = 0
    while (n%(10**e))//(10**(e-1)) != 0:
        n1 = (n%(10**e))//(10**(e-1))
        nuevo_n += n1*(10**(ex-1))
        ex -= 1
        e += 1
    if n == nuevo_n:
        return True
    else:
        return False
main()