def main():
    epic()
def epic():
    n = int(input("Ingrese un numero entero: "))
    n1 = n//100000000
    n2 = n//10000000%10
    n3 = n//1000000%10
    n4 = n//100000%10
    n5 = n//10000%10
    n6 = n//1000%10
    n7 = n//100%10
    n8 = n//10%10
    n9 = n//1%10
    
    c1 = n9*100000000
    c2 = n8*10000000
    c3 = n7*1000000
    c4 = n6*100000
    c5 = n5*10000
    c6 = n4*1000
    c7 = n3*100
    c8 = n2*10
    c9 = n1
    
    cs = c1+c2+c3+c4+c5+c6+c7+c8+c9
    print(cs)
main()