def main():
    n = int(input("Ingrese un numero de 4 cifras: "))
    if validar(n) == True:
        print("Cumple")
    else:
        print("No cumple")
    print(mult())
def validar(n):
    mil = n//1000
    cent = n//100%10
    dec = n%100//10
    prim = n%10
    if (mil + dec) == (cent + prim):
        return True
    else:
        return False
def mult():
    for i in range(1000,9999):
        mil = i//1000
        cent = i//100%10
        dec = i%100//10
        prim = i%10
        if (mil + dec) == (cent + prim):
            print(i)
             
main()
    