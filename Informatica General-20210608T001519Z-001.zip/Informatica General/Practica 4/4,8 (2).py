def main():
    e = 1
    total = 0
    n = int(input("Ingrese un numero entero: "))
    if n>0:
        while (n-e) != 0:
            if e == 1:
                total += n*(n-e)
                e += 1
            else:
                total *= (n-e)
                e += 1
        print("El factorial de {} es: {}".format(n,total))
    else:
        print("No se puede hacer factorial de numero negativo...")
main()
