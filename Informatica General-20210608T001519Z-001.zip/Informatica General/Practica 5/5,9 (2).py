def main():
    text = str(input("Ingrese un texto: "))
    print("El texto tiene {} palabras, la de mayor longitud es  y la de menor longitud es''".format(cant(text)))
    
def cant(text):
    texto = ""
    cant = 0
    total = 0
    for i in text:
        if (i == " ") and (text[total-1] != " "):
            texto = ""
            cant += 1
            total += 1               
        elif (("a"<=i<="z") == True) or (("A"<=i<="Z") == True):
            texto += i
    
    if (("a"<=text[len(text)-1]<="z") == True) or (("A"<=text[len(text)-1]<="Z") == True):
        cant += 1
    return cant
"""
def mayor(text):
    pal = ""
    mayor = ""
    for i in text:
        pal += i
        if len(text)>len(mayor):
            mayor = ""
            mayor += pal
        elif i == " ":
            pal = ""
    return mayor

def menor(text):
    pal = ""
    menor = ""
    for i in text:
        pal += i
        if len(pal)<len(menor):
            menor = ""
            menor+= pal
        elif i == " ":
            pal = ""
    return menor
    """
main()
