def main():
    pal = str(input("Ingresar palabra: "))
    while len(pal) < 2:
        pal = str(input("Error. Ingresar palabra: "))
    pal1 = len(pal)
    pal2 = (pal[len(pal)-2:len(pal)])*3
    print(pal2)
main()
        