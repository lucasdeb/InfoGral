def main():
    word = str(input())
    freq = int(input())
    words = words.split()
    
def wordsoffrequency(words,freq):
    test_word = words[j]
    a = 0
    j = 0
        for i in words:
            if i == test_word
                x += 1
                
            else:
                j = x
                test_word = words [j]
    
    
    
    
    
    
main()