"""
revisar bien (Encontrar si la palabra tiene espacios o no
"""
def main():
    txt = str(input("Ingrese texto: "))
    x = ""
    for h in txt:
        if h != " ":
            h += x
    if txt[len(txt)-len(x):len(txt)] == x:
        print("cumple")
    else:
        print("No cumple")
main()
    
    