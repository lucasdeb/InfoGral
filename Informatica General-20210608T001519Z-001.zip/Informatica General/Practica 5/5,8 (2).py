def main():
    text = str(input("Ingrese un texto: "))
    print(mayuscula(text))

def mayuscula(text):
    text1 = ""
    total = 0
    cont = 0
    while total != len(text):
        while cont == 0:
            if ("a"<=text[total]<="z") == True:
                num = ord(text[total])
                text1 += chr(num-32)
                total += 1
                cont += 1
            elif ("A"<=text[total]<="Z") == True:
                cont += 1
                text1 += text[total]
                total += 1
            else:
                cont += 1
                text1 += text[total]
                total += 1
        if (("a"<=text[total]<="z") == True) and (text[total-1] == " "):
                num = ord(text[total])
                text1 += chr(num-32)
                total += 1
        else:
            text1 += text[total]
            total +=1
    return text1
main()