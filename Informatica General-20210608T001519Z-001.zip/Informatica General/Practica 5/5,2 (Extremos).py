def main():
    ext = str(input("Ingresar extremos: "))
    if len(ext) < 2:
        ext = str(input("Ingresar extremos: "))
    pal = str(input("Ingresar palabra: "))
    print(ext[0]+pal+ext[1])
main()