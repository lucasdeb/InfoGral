def main():
    text = str(input("Ingrese un texto: "))
    while len(text)%2 != 0:
        text = str(input("Error. Ingrese un texto: "))
    print(rotacion(text))
    
def rotacion(text):
    prim = text[0:len(text)//2]
    final = text[len(text)//2:len(text)]
    return final+prim
main()
    