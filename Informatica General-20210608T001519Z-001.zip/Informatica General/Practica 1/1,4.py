def main():
    num = float(input("ingrese numero:"))
    entera = (num//1)
    frac = num%1
    print("parte fraccionaria:", frac, "parte entera:", entera)
    
main()