def main():
    x = int(input("ingrese primer numero:"))
    y = int(input("ingrese segundo numero:"))
    n1 = x%10//1
    n2 = y%100//10
    print("El numero reslutante es: {}{}".format(n1,n2))
    
main()