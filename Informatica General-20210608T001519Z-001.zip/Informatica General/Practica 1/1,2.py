def main():
    n = str(input("Ingrese su Nombre: "))
    a = str(input("Ingrese su Apellido: "))
    
    print("Hola {} {}!".format(n,a))
main()
