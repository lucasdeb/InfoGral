def main():
    x = int(input("ingrese numero de 5 digitos:"))
    n1 = x//10000
    n2 = x%10000//1000
    n3 = x%1000//100
    n4 = x%100//10
    n5 = x%10//1
    
    n6 = n1**2
    n7 = n2**2
    n8 = n3**2
    n9 = n4**2
    n0 = n5**2
    
    print(n6, n7, n8, n9, n0)
main()

    