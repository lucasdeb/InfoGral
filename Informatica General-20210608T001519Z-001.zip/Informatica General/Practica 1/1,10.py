def main():
    num = int(input("ingrese un numero binario de hasta 5 bits:"))
    
main()
    

    
    
    
    