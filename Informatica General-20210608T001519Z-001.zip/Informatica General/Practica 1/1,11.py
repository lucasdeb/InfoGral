def main():
    num = int(input("ingrese numero base 10:"))
    o = octal(num)
    print(o)
def octal(num):
    n1 = num%8
    n2 = (num//8)%8
    n3 = (num//8**2)%8
    n4 = (num//8**3)%8
    n5 = (num//8**4)%8
    o = n1+n2*10+n3*100+n4*1000+n5*10000
    return o

main()

    
    