def main():
    b = int(input("Ingrese la base: "))
    a = int(input("Ingrese la altura: "))
    
    p = (b*2)+(a*2)
    
    ar = b*a
    
    print("Perimentro: {}".format(p))
    print("Area: {}".format(ar))
    
main()